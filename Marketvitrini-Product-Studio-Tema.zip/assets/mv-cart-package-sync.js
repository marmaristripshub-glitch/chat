/* Use Horizon's own update path so summary, cart drawer and header stay in sync. */
(() => {
  if (window.__mvCartPackageSyncReady) return;
  window.__mvCartPackageSyncReady = true;
  let busy = false;
  document.addEventListener('click', async (event) => {
    const button = event.target.closest?.('[data-mv-cart-quantity]');
    if (!button || button.disabled || busy || button.getAttribute('aria-pressed') === 'true') return;
    const control = button.closest('[data-mv-cart-package]');
    const cart = control?.closest('cart-items-component:not([data-drawer])');
    const quantity = Number(button.dataset.mvCartQuantity);
    if (!cart || !Number.isInteger(quantity) || quantity < 1 || quantity > 3) return;
    event.preventDefault();
    busy = true;
    const key = control.dataset.lineKey;
    const states = new Map([...cart.querySelectorAll('[data-mv-cart-quantity]')].map((el) => [el, el.disabled]));
    const feedback = control.querySelector('.mv-cart-package__feedback');
    let result;
    const observe = (update) => {
      if (update.target === cart && update.promise) {
        // Consume rejections immediately; native updateQuantity also renders its error state.
        result = update.promise.then(() => ({ ok: true }), (error) => ({ ok: false, error }));
      }
    };
    try {
      await customElements.whenDefined('cart-items-component');
      if (cart.constructor.pendingQuantityUpdates?.length) return;
      const rows = [...cart.querySelectorAll('[ref="cartItemRows[]"]')];
      const line = rows.findIndex((row) => row.dataset.key === key) + 1;
      if (!line || typeof cart.updateQuantity !== 'function') throw new Error('Sepet hazırlanamadı. Sayfayı yenileyip tekrar deneyin.');
      states.forEach((_, el) => { el.disabled = true; });
      control.setAttribute('aria-busy', 'true');
      if (feedback) { feedback.hidden = false; feedback.textContent = 'Sepet güncelleniyor…'; }
      document.addEventListener('shopify:cart:lines-update', observe);
      await cart.updateQuantity({ line, quantity, action: 'change' });
      const outcome = result ? await result : undefined;
      if (!outcome) throw new Error('Sepet sonucu doğrulanamadı. Sayfayı yenileyin.');
      if (outcome.ok === false) throw outcome.error;
      const nextControl = [...document.querySelectorAll('[data-mv-cart-package]')].find((el) => el.dataset.lineKey === key);
      const nextFeedback = nextControl?.querySelector('.mv-cart-package__feedback');
      if (nextFeedback) { nextFeedback.hidden = false; nextFeedback.textContent = 'Sepet güncellendi.'; }
      nextControl?.querySelector(`[data-mv-cart-quantity="${quantity}"]`)?.focus({ preventScroll: true });
    } catch (error) {
      if (feedback?.isConnected) {
        feedback.hidden = false;
        feedback.textContent = error?.message || 'Sepet güncellenemedi. Lütfen tekrar deneyin.';
      }
    } finally {
      document.removeEventListener('shopify:cart:lines-update', observe);
      states.forEach((disabled, el) => { if (el.isConnected) el.disabled = disabled; });
      control.removeAttribute('aria-busy');
      busy = false;
    }
  });
})();
