/* Shared variant state for MarketVitrini sections and Horizon product pickers. */
(() => {
  if (window.MarketVitrini?.variantSyncReady) return;
  const states = new Map();
  const revisions = new Map();
  const formatters = new Map();
  const id = (value) => String(value ?? '').split('/').pop();
  const cents = (value) => {
    if (value == null || value === '') return undefined;
    const number = typeof value === 'object' ? Math.round(Number(value.amount) * 100) : Number(value);
    return Number.isFinite(number) ? number : undefined;
  };
  function money(value) {
    const currency = document.documentElement.dataset.currency || window.Shopify?.currency?.active || 'TRY';
    const locale = document.documentElement.lang || 'tr-TR';
    const key = `${locale}:${currency}`;
    try {
      if (!formatters.has(key)) formatters.set(key, new Intl.NumberFormat(locale, { style: 'currency', currency }));
      return formatters.get(key).format((Number(value) || 0) / 100);
    } catch {
      return ((Number(value) || 0) / 100).toFixed(2);
    }
  }
  function render(root, detail) {
    root.querySelectorAll('input[name="id"], [data-variant-id]').forEach((input) => { input.value = detail.variantId; });
    root.querySelectorAll('[data-mv-variant-select]').forEach((select) => { select.value = detail.variantId; });
    root.querySelectorAll('[data-mv-price]').forEach((el) => {
      if (detail.price != null) el.textContent = money(detail.price);
    });
    root.querySelectorAll('[data-mv-compare]').forEach((el) => {
      if (detail.price == null || detail.compareAtPrice == null) return;
      el.hidden = detail.compareAtPrice <= detail.price;
      el.textContent = el.hidden ? '' : money(detail.compareAtPrice);
    });
    root.querySelectorAll('[data-h7-discount], [data-mv-discount]').forEach((el) => {
      const discounted = detail.compareAtPrice > detail.price;
      el.hidden = !discounted;
      if (discounted) {
        const text = el.dataset.discountLabel || (el.dataset.discountLabel = el.textContent.replace(/%\d+\s*/, '').trim());
        el.textContent = `%${Math.round((detail.compareAtPrice - detail.price) * 100 / detail.compareAtPrice)} ${text}`;
      }
    });
    if (root.hasAttribute('data-mv-transfer-rate') && detail.price != null) {
      const saving = Math.floor(detail.price * Number(root.dataset.mvTransferRate) / 100);
      const price = root.querySelector('[data-mv-transfer-price]');
      const saved = root.querySelector('[data-mv-transfer-saving]');
      if (price) price.textContent = money(detail.price - saving);
      if (saved) saved.textContent = `${money(saving)} ${saved.dataset.savingLabel}`;
    }
    root.querySelectorAll('[data-mv-add]').forEach((button) => {
      if (typeof detail.available !== 'boolean') return;
      button.dataset.mvAvailable = String(detail.available);
      button.disabled = !detail.available || button.dataset.mvBusy === 'true';
      const label = button.querySelector('[data-mv-add-label]');
      if (label && button.dataset.mvBusy !== 'true') {
        label.textContent = detail.available ? button.dataset.availableText : button.dataset.soldText;
      }
    });
    root.querySelectorAll('[data-mv-unit-price]').forEach((el) => {
      if (detail.price != null) el.dataset.mvUnitPrice = detail.price;
    });
    root.dispatchEvent(new CustomEvent('mv:variant-applied', { detail }));
  }
  function applyVariant(raw) {
    if (!raw) return;
    const variant = raw.variant || {};
    const productId = id(raw.productId || raw.product?.id);
    const variantId = id(raw.variantId || variant.id || raw.id);
    if (!productId || !variantId) return;
    const previous = states.get(productId);
    const sameVariant = previous?.variantId === variantId;
    const detail = {
      ...(sameVariant ? previous : {}), productId, variantId,
      price: cents(raw.price ?? variant.price) ?? (sameVariant ? previous?.price : undefined),
      compareAtPrice: cents(raw.compareAtPrice ?? variant.compare_at_price ?? variant.compareAtPrice) ?? 0,
      available: raw.available ?? variant.available ?? variant.availableForSale ?? (sameVariant ? previous?.available : undefined),
    };
    // Retain the legacy shape used by the package sections.
    detail.variant = { id: variantId, price: detail.price, compare_at_price: detail.compareAtPrice, available: detail.available };
    states.set(productId, detail);
    document.querySelectorAll(`[data-mv-product-id="${CSS.escape(productId)}"]`).forEach((root) => render(root, detail));
  }
  function publish(detail) {
    const productId = id(detail.productId);
    revisions.set(productId, (revisions.get(productId) || 0) + 1);
    document.dispatchEvent(new CustomEvent('mv:variant-change', { detail }));
  }
  document.addEventListener('mv:variant-change', (event) => applyVariant(event.detail));
  document.addEventListener('change', (event) => {
    const select = event.target.closest?.('[data-mv-variant-select]');
    const option = select?.selectedOptions[0];
    if (!option) return;
    publish({ productId: select.dataset.productId, variantId: option.value, price: option.dataset.price,
      compareAtPrice: option.dataset.compare, available: option.dataset.available === 'true' });
  });
  document.addEventListener('shopify:product:select', async (event) => {
    // Standard events expose product/promise on the event; older integrations use detail.
    const payload = event.product ? event : event.detail;
    const productId = id(payload?.product?.id);
    if (!productId || !payload?.promise) return;
    const revision = (revisions.get(productId) || 0) + 1;
    revisions.set(productId, revision);
    try {
      const resolved = await payload.promise;
      if (revision !== revisions.get(productId)) return;
      const variant = resolved?.variant;
      if (!variant) {
        const previous = states.get(productId);
        if (previous) applyVariant({ ...previous, available: false });
        else document.querySelectorAll(`[data-mv-product-id="${CSS.escape(productId)}"]`).forEach((root) => {
          root.querySelectorAll('[data-mv-add], [data-add-button]').forEach((button) => {
            button.disabled = true;
            button.dataset.mvAvailable = 'false';
          });
          root.dispatchEvent(new CustomEvent('mv:variant-applied', { detail: { productId, available: false } }));
        });
        return;
      }
      let ajaxVariant;
      const json = resolved.detail?.html?.querySelector('variant-picker script[type="application/json"]')?.textContent;
      try { ajaxVariant = json ? JSON.parse(json) : undefined; } catch { /* Optional comparison data. */ }
      if (id(ajaxVariant?.id) !== id(variant.id)) ajaxVariant = undefined;
      publish({ productId, variantId: id(variant.id), price: cents(variant.price),
        compareAtPrice: cents(ajaxVariant?.compare_at_price ?? variant.compareAtPrice ?? variant.compare_at_price) ?? 0,
        available: variant.availableForSale ?? variant.available });
    } catch { /* Aborted/failed Horizon requests must not replace the last valid selection. */ }
  });
  function hydrate(scope = document) {
    scope.querySelectorAll('[data-mv-variant-select]').forEach((select) => {
      const option = select.selectedOptions[0];
      if (!states.has(id(select.dataset.productId)) && option) {
        applyVariant({ productId: select.dataset.productId, variantId: option.value, price: option.dataset.price,
          compareAtPrice: option.dataset.compare, available: option.dataset.available === 'true' });
      }
    });
    scope.querySelectorAll('[data-mv-product-id]').forEach((root) => {
      const state = states.get(id(root.dataset.mvProductId));
      if (state) render(root, state);
    });
  }
  window.MarketVitrini = { ...window.MarketVitrini, applyVariant, money, variantSyncReady: true };
  hydrate();
  document.addEventListener('DOMContentLoaded', () => hydrate(), { once: true });
  document.addEventListener('shopify:section:load', (event) => hydrate(event.target));
})();
