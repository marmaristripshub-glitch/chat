/* Re-initialize interactive sections when the Shopify editor replaces their markup. */
(() => {
  const cleanups = new Map();
  function sticky(bar) {
    const controller = new AbortController();
    const options = { signal: controller.signal };
    const form = bar.querySelector('[data-mvs-form]');
    const quantity = form?.elements.quantity;
    const button = bar.querySelector('[data-mv-add]');
    const label = button?.querySelector('[data-mv-add-label]');
    const total = bar.querySelector('[data-mvs-subtotal]');
    const feedback = bar.querySelector('.mvs-v14__feedback');
    if (!form || !quantity || !button) return () => {};
    let busy = false;
    let frame = 0;
    const available = () => button.dataset.mvAvailable !== 'false';
    button.dataset.mvAvailable = String(!button.disabled);
    function count() {
      const min = Number(quantity.min) || 1;
      const max = Number(quantity.max) || 99;
      const step = Number(quantity.step) || 1;
      const value = Number(quantity.value);
      const rounded = min + Math.round(((Number.isFinite(value) ? value : min) - min) / step) * step;
      return Math.max(min, Math.min(max, rounded));
    }
    function update(commit = false) {
      const value = count();
      if (commit) quantity.value = value;
      total.textContent = window.MarketVitrini.money(Number(bar.dataset.unitCents) * value);
      bar.querySelector('[data-minus]').disabled = value <= (Number(quantity.min) || 1);
      bar.querySelector('[data-plus]').disabled = value >= (Number(quantity.max) || 99);
    }
    for (const [selector, direction] of [['[data-minus]', -1], ['[data-plus]', 1]]) {
      bar.querySelector(selector).addEventListener('click', () => {
        quantity.value = count() + direction * (Number(quantity.step) || 1);
        update(true);
      }, options);
    }
    quantity.addEventListener('input', () => update(), options);
    quantity.addEventListener('change', () => update(true), options);
    const selector = '[data-mv-primary-product],.mv-veloura,.mvh,.mv10,.mvx,.mv-premcta,.product-information';
    function visibility() {
      frame = 0;
      const hero = [...document.querySelectorAll(selector)].find((el) => el !== bar && el.getClientRects().length && el.closest('main'));
      const below = hero ? hero.getBoundingClientRect().bottom < 12 : window.scrollY > 400;
      // Keep a keyboard user's focused control visible while scrolling.
      bar.classList.toggle('is-visible', below || bar.contains(document.activeElement));
    }
    function schedule() { if (!frame) frame = requestAnimationFrame(visibility); }
    window.addEventListener('scroll', schedule, { ...options, passive: true });
    window.addEventListener('resize', schedule, { ...options, passive: true });
    // Horizon may scroll its page wrapper instead of the window.
    document.querySelector('.page-wrapper')?.addEventListener('scroll', schedule, { ...options, passive: true });
    bar.addEventListener('focusout', schedule, options);
    bar.addEventListener('mv:variant-applied', (event) => {
      if (event.detail.price != null) bar.dataset.unitCents = event.detail.price;
      update();
    }, options);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (busy || !available()) return;
      const variantId = form.elements.id?.value;
      if (!variantId) return;
      busy = true;
      button.dataset.mvBusy = 'true';
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      feedback.hidden = true;
      label.textContent = 'Ekleniyor…';
      update(true);
      try {
        const response = await fetch(bar.dataset.addUrl, {
          method: 'POST', credentials: 'same-origin', signal: controller.signal,
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ id: variantId, quantity: count() }),
        });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.description || payload.message || 'Ürün sepete eklenemedi.');
        window.location.assign(bar.dataset.cartUrl);
      } catch (error) {
        if (error.name !== 'AbortError') {
          feedback.textContent = error.message || 'Bir hata oluştu. Lütfen tekrar deneyin.';
          feedback.hidden = false;
        }
      } finally {
        busy = false;
        delete button.dataset.mvBusy;
        button.removeAttribute('aria-busy');
        button.disabled = !available();
        label.textContent = available() ? button.dataset.availableText : button.dataset.soldText;
      }
    }, options);
    update(true);
    visibility();
    return () => { controller.abort(); cancelAnimationFrame(frame); };
  }
  function countdown(root) {
    const deadline = Date.parse(root.dataset.end);
    const timer = root.querySelector('[data-mv-countdown]');
    const status = root.querySelector('[data-mv-countdown-status]');
    let interval;
    function tick() {
      const remaining = Math.max(0, deadline - Date.now());
      const active = Number.isFinite(deadline) && remaining > 0;
      timer.hidden = !active;
      status.hidden = active || !Number.isFinite(deadline);
      if (!active) { clearInterval(interval); return; }
      const values = [Math.floor(remaining / 86400000), Math.floor(remaining / 3600000) % 24,
        Math.floor(remaining / 60000) % 60, Math.floor(remaining / 1000) % 60];
      ['d','h','m','s'].forEach((unit, index) => { root.querySelector(`[data-${unit}]`).textContent = String(values[index]).padStart(2, '0'); });
    }
    if (Number.isFinite(deadline) && deadline > Date.now()) interval = setInterval(tick, 1000);
    tick();
    return () => clearInterval(interval);
  }
  function bundle(root) {
    const controller = new AbortController();
    const cards = [...root.querySelectorAll('[data-mv-package]')];
    const quantity = root.querySelector('[name="quantity"]');
    function choose(card) {
      cards.forEach((el) => { const active = el === card; el.classList.toggle('is-active', active); el.setAttribute('aria-pressed', String(active)); });
      quantity.value = card.dataset.qty;
      root.querySelector('.mv-bundle-selected').textContent = card.querySelector('strong').textContent;
      root.querySelector('.mv-bundle-total').textContent = card.dataset.money;
    }
    cards.forEach((card) => card.addEventListener('click', () => choose(card), { signal: controller.signal }));
    root.addEventListener('mv:variant-applied', (event) => {
      const detail = event.detail;
      if (detail.price == null) return;
      cards.forEach((card) => {
        const value = detail.price * Number(card.dataset.qty);
        card.dataset.money = window.MarketVitrini.money(value);
        card.querySelector('[data-package-price]').textContent = card.dataset.money;
      });
      if (cards.length) choose(cards.find((el) => el.classList.contains('is-active')) || cards[0]);
    }, { signal: controller.signal });
    if (cards.length) choose(cards[0]);
    return () => controller.abort();
  }
  function initialize(scope = document) {
    for (const [selector, init] of [['.mvs-v14', sticky], ['[data-mv-campaign]', countdown], ['[data-mv-package-picker]', bundle]]) {
      const roots = [...scope.querySelectorAll(selector)];
      if (scope.matches?.(selector)) roots.unshift(scope);
      roots.forEach((root) => { if (!cleanups.has(root)) cleanups.set(root, init(root)); });
    }
  }
  document.addEventListener('shopify:section:unload', (event) => {
    for (const [root, cleanup] of cleanups) {
      if (root === event.target || event.target.contains(root)) { cleanup(); cleanups.delete(root); }
    }
  });
  document.addEventListener('shopify:section:load', (event) => initialize(event.target));
  initialize();
})();
