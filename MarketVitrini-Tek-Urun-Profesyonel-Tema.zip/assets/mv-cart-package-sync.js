/** MarketVitrini PRO — Shopify Cart Page 1/2/3 quantity sync.
 * Keeps native Horizon cart table/checkout. Shopify /cart/change.js is the only mutation.
 * Re-renders the Shopify cart section after the mutation without full page reload.
 * Shopify is the authoritative source for prices, discounts and totals.
 */
(() => {
  if (window.__mvCartPackageSyncReady) return;
  window.__mvCartPackageSyncReady = true;
  const config = document.querySelector('[data-mv-cart-pack-config]');
  if (!config) return;
  const root = config.dataset.rootUrl || '/';
  let busy = false;
  const rootPath = root.endsWith('/') ? root : root + '/';
  const endpoint = rootPath + 'cart/change.js';
  const cartComponent = document.querySelector('cart-items-component:not([data-drawer])');
  const sectionId = cartComponent?.dataset.sectionId;

  document.addEventListener('click', async (event) => {
    const btn = event.target.closest('[data-mv-cart-quantity]');
    if (!btn || !document.body.contains(btn) || busy || btn.disabled) return;
    const control = btn.closest('[data-mv-cart-package]');
    if (!control) return;
    const key = control.dataset.lineKey;
    const qty = Number(btn.dataset.mvCartQuantity);
    if (!key || !Number.isInteger(qty) || qty < 1 || qty > 3) return;
    if (btn.getAttribute('aria-pressed') === 'true') return;

    busy = true;
    const buttons = [...document.querySelectorAll('[data-mv-cart-quantity]')];
    buttons.forEach(b => b.disabled = true);
    const feedback = control.querySelector('.mv-cart-package__feedback');
    if (feedback) {feedback.textContent = 'Sepet güncelleniyor...';feedback.hidden = false;}

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: {'Content-Type':'application/json','Accept':'application/json'},
        body: JSON.stringify({id:key, quantity:qty, sections:sectionId ? [sectionId] : [], sections_url:window.location.pathname})
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.description || data.message || 'Paket adedi güncellenemedi.');
      // Shopify returns the newly rendered section, including the order summary.
      // Replace only the cart component contents: preserve its custom-element host
      // and the theme's page layout, rather than triggering a slow navigation.
      let html = data.sections && sectionId ? data.sections[sectionId] : null;
      if (!html && sectionId) {
        const url = new URL(window.location.href);
        url.searchParams.set('section_id', sectionId);
        const sectionResponse = await fetch(url.toString(), {credentials:'same-origin',cache:'no-store'});
        if (sectionResponse.ok) html = await sectionResponse.text();
      }
      if (!html) throw new Error('Sipariş özeti yeniden yüklenemedi. Sepet güncellendi; sayfayı yenileyin.');
      const parsed = new DOMParser().parseFromString(html, 'text/html');
      const nextCartComponent = parsed.querySelector('cart-items-component:not([data-drawer])');
      const currentCartComponent = document.querySelector('cart-items-component:not([data-drawer])');
      if (!nextCartComponent || !currentCartComponent) throw new Error('Sepet bölümü bulunamadı. Sepet güncellendi; sayfayı yenileyin.');
      currentCartComponent.replaceChildren(...Array.from(nextCartComponent.childNodes).map(node => document.importNode(node, true)));
      // Update optional cart counters that listen for a cart notification.
      document.dispatchEvent(new CustomEvent('mv:cart-updated', {detail:{cart:data}}));
      busy = false;
    } catch (error) {
      busy = false;
      buttons.forEach(b => {b.disabled = b.hasAttribute('aria-disabled');});
      if (feedback) {feedback.textContent = error?.message || 'Sepet güncellenemedi.';feedback.hidden = false;}
    }
  });
})();
