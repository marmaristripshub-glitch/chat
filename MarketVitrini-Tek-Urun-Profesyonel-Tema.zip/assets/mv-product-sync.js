(() => {
  const money = (cents) => {
    try {
      const currency = document.documentElement.dataset.currency || window.Shopify?.currency?.active || 'TRY';
      return new Intl.NumberFormat(document.documentElement.lang || 'tr-TR', { style:'currency', currency }).format((Number(cents)||0)/100);
    } catch(e) { return ((Number(cents)||0)/100).toFixed(2); }
  };

  function applyVariant(raw) {
    if (!raw) return;
    const variant = raw.variant || {};
    const detail = {
      productId: raw.productId || raw.product?.id,
      variantId: raw.variantId || variant.id || raw.id,
      price: raw.price ?? variant.price,
      compareAtPrice: raw.compareAtPrice ?? variant.compare_at_price,
      available: raw.available ?? variant.available,
      min: raw.min ?? variant.quantity_rule?.min,
      increment: raw.increment ?? variant.quantity_rule?.increment,
      max: raw.max ?? variant.quantity_rule?.max
    };
    if (!detail.productId || !detail.variantId) return;
    const selector = `[data-mv-product-id="${CSS.escape(String(detail.productId))}"]`;
    document.querySelectorAll(selector).forEach((root) => {
      root.querySelectorAll('input[name="id"]').forEach((el) => el.value = detail.variantId);
      root.querySelectorAll('[data-mv-price]').forEach((el) => { if (detail.price != null) el.textContent = money(detail.price); });
      root.querySelectorAll('[data-mv-compare]').forEach((el) => {
        if (detail.compareAtPrice == null || detail.price == null) return;
        const show = Number(detail.compareAtPrice) > Number(detail.price);
        el.hidden = !show;
        if (show) el.textContent = money(detail.compareAtPrice);
      });
      root.querySelectorAll('[data-mv-add]').forEach((btn) => {
        btn.disabled = detail.available === false;
        if (btn.dataset.availableText && btn.dataset.soldText) {
          const label = btn.querySelector('[data-mv-add-label]');
          if (label) label.textContent = detail.available === false ? btn.dataset.soldText : btn.dataset.availableText;
        }
      });
      root.querySelectorAll('[data-mv-unit-price]').forEach((el) => { if (detail.price != null) el.dataset.mvUnitPrice = detail.price; });
      root.dispatchEvent(new CustomEvent('mv:variant-applied', { detail }));
    });
  }
  document.addEventListener('mv:variant-change', (event) => applyVariant(event.detail));

  document.addEventListener('change', (event) => {
    const select = event.target.closest?.('[data-mv-variant-select]');
    if (!select) return;
    const option = select.options[select.selectedIndex];
    const detail = {
      productId: select.dataset.productId,
      variantId: option.value,
      price: option.dataset.price,
      compareAtPrice: option.dataset.compare,
      available: option.dataset.available === 'true'
    };
    applyVariant(detail);
    document.dispatchEvent(new CustomEvent('mv:variant-change', { detail }));
  });

  // Horizon product picker compatibility on product templates.
  document.addEventListener('shopify:product:select', async (event) => {
    const variantId = event.detail?.variantId || event.detail?.detail?.variantId;
    const productId = event.detail?.product?.id;
    if (!variantId || !productId) return;
    let detail = { productId, variantId };
    try {
      const resolved = await event.detail?.promise;
      const v = resolved?.variant;
      if (v) detail = { productId, variantId: v.id || variantId, price: v.price, compareAtPrice: v.compare_at_price, available: v.available };
    } catch(e) {}
    applyVariant(detail);
    document.dispatchEvent(new CustomEvent('mv:variant-change', { detail }));
  });

  window.MarketVitrini = window.MarketVitrini || {};
  window.MarketVitrini.applyVariant = applyVariant;
  window.MarketVitrini.money = money;
})();
